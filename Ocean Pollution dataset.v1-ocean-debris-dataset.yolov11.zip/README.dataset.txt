# Ocean Pollution dataset > ocean-debris-dataset
https://universe.roboflow.com/ratheshan-sathiyamoorthy/ocean-pollution-dataset

Provided by a Roboflow user
License: CC BY 4.0

